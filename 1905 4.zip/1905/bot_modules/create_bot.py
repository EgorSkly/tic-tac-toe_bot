
from aiogram import Bot, Dispatcher
dp = Dispatcher()

TOKEN = ""

bot = Bot(TOKEN)
